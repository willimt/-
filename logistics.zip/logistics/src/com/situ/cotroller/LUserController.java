package com.situ.cotroller;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.situ.dao.LUserDao;
import com.situ.entity.CUser;
import com.situ.entity.LUser;

import com.situ.utils.JsonInfo;
import com.situ.utils.MD5Util;
import com.situ.utils.SearchInfo;

@Controller
@RequestMapping("LUser")
public class LUserController {
	
	@Autowired
	LUserDao dao;
	
	
	//������һ��dao�����Զ�ע�룬��һ����û���������,����Ӫ�������л�ȡ

	@RequestMapping("index")
	public String index(@RequestParam(defaultValue="",value="txt") String t,SearchInfo info,ModelMap m) {
		if(t.length()>0)
			info.setWhere(" where orders.goods_name like '%"+t+"%' ");
		m.put("list", dao.select(info));
		m.put("search", info);
		m.put("txt",t);
		return "LUser/index";
	}
	@RequestMapping("delete")
	public String delete(int id,ModelMap m) {
		dao.delete(id);
		return index("",new SearchInfo(),m);
	}
	@RequestMapping("insert")
	public @ResponseBody JsonInfo insert(LUser u,ModelMap m) {
		LUser user=dao.getByName(u.getUsername());
		if(user!=null)return new JsonInfo(0);
		if(u.getAddress()==""||u.getHotline()==""||u.getCompany()==""||u.getUsername()==""||u.getPassword()=="")return new JsonInfo(0);
		dao.insert(u);
		return new JsonInfo(1);
	}
	@RequestMapping("update")
	public @ResponseBody JsonInfo update(LUser u,ModelMap m,HttpServletRequest req) {//string name= User u
		if(u.getAddress()==""||u.getHotline()==""||u.getCompany()==""||u.getUsername()=="")return new JsonInfo(0);
		dao.update(u);
		HttpSession s=req.getSession();
		s.setAttribute("user", u);
		return new JsonInfo(1);
	}
	
	@RequestMapping("changepass")
	public @ResponseBody JsonInfo changepass(String password,String newpass1,String newpass2,ModelMap m,HttpServletRequest req) {//string name= User u

		HttpSession s=req.getSession();
		LUser user=(LUser) s.getAttribute("user");
		if(user.getPassword().equals(password)&&newpass1.equals(newpass2)) {
			user.setPassword(newpass1);
			s.setAttribute("user", user);
			dao.updatepass(user);
			
			return new JsonInfo(1);
		}
		return new JsonInfo(0);
	}
	
	@RequestMapping("add")
	public String add(ModelMap m) {//string name= User u

		return "LUser/edit";
	}
	
	@RequestMapping("sign")
	public String sign(ModelMap m) {
		return "LUser/sign_up";
	}
	@RequestMapping("edit")
	public String edit(int id,ModelMap m) {//string name= User u
		m.put("info", dao.getById(id));
		return add(m);
	}
	
	@RequestMapping("login")
	public String login(LUser u,ModelMap m,HttpServletRequest req) {//string name= User u
		LUser user=dao.login(u);
		if(user==null&&u.getPassword()!=null) {
			return "redirect:../login.html";
		}else {
			HttpSession s=req.getSession();
			s.setMaxInactiveInterval(100);
			s.setAttribute("user", user);
			return "redirect:../index.jsp";
		}
	}
}
 