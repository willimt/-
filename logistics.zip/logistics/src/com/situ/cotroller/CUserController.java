package com.situ.cotroller;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.situ.dao.CUserDao;
import com.situ.entity.CUser;
import com.situ.entity.LUser;
import com.situ.utils.JsonInfo;
import com.situ.utils.MD5Util;
import com.situ.utils.SearchInfo;

@Controller
@RequestMapping("CUser")
public class CUserController {
	
	@Autowired
	CUserDao dao;
	
	
	//������һ��dao�����Զ�ע�룬��һ����û���������,����Ӫ�������л�ȡ

	@RequestMapping("index")
	public String index(@RequestParam(defaultValue="",value="txt") String t,SearchInfo info,ModelMap m) {
		if(t.length()>0)
			info.setWhere(" where orders.goods_name like '%"+t+"%' ");
		m.put("list", dao.select(info));
		m.put("search", info);
		m.put("txt",t);
		return "CUser/index";
	}
	@RequestMapping("delete")
	public String delete(int id,ModelMap m) {
		dao.delete(id);
		return index("",new SearchInfo(),m);
	}
	@RequestMapping("insert")
	public @ResponseBody JsonInfo insert(CUser u,ModelMap m) {
		CUser user=dao.getByName(u.getUsername());
		if(user!=null)return new JsonInfo(0);
		if(u.getAddress()==""||u.getContact()==""||u.getName()==""||u.getUsername()==""||u.getPassword()=="")return new JsonInfo(0);
		dao.insert(u);
		return new JsonInfo(1);
	}

	@RequestMapping("update")
	public @ResponseBody JsonInfo update(CUser u,ModelMap m,HttpServletRequest req) {//string name= User u
		if(u.getAddress()==""||u.getContact()==""||u.getName()==""||u.getUsername()=="")return new JsonInfo(0);
		dao.update(u);
		HttpSession s=req.getSession();
		s.setAttribute("user", u);
		return new JsonInfo(1);
	}
	
	@RequestMapping("changepass")
	public @ResponseBody JsonInfo changepass(String password,String newpass1,String newpass2,HttpServletRequest req) {//string name= User u

		HttpSession s=req.getSession();
		CUser user=(CUser) s.getAttribute("user");
		if(user.getPassword().equals(password)&&newpass1.equals(newpass2)) {
			user.setPassword(newpass1);
			s.setAttribute("user", user);
			dao.updatepass(user);
			return new JsonInfo(1);
		}
		return new JsonInfo(0);
	}
	
	@RequestMapping("add")
	public String add(ModelMap m) {//string name= User u

		return "CUser/edit";
	}
	
	@RequestMapping("sign")
	public String sign(ModelMap m) {

		return "CUser/sign_up";
	}
	
	@RequestMapping("out")
	public String out(ModelMap m,HttpServletRequest req) {
		HttpSession s=req.getSession();
		s.invalidate();
		return "redirect:../login.html";
	}
	
	@RequestMapping("edit")
	public String edit(int id,ModelMap m) {//string name= User u
		m.put("info", dao.getById(id));
		return add(m);
	}
	
	@RequestMapping("login")
	public String login(CUser u,ModelMap m,HttpServletRequest req) {//string name= User u
		CUser user=dao.login(u);
		if(user==null&&u.getPassword()!=null) {
			return "redirect:../login.html";
		}else {
			HttpSession s=req.getSession();
			s.setMaxInactiveInterval(100);
			s.setAttribute("user", user);
			s.setAttribute("common", "1");
			return "redirect:../index.jsp";
		}
	}
}
 