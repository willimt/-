package com.situ.cotroller;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.situ.dao.OrdersDao;
import com.situ.dao.OrdersDao;
import com.situ.entity.CUser;
import com.situ.entity.Orders;

import com.situ.utils.JsonInfo;
import com.situ.utils.MD5Util;
import com.situ.utils.SearchInfo;

@Controller
@RequestMapping("Order")
public class OrderController {
	
	@Autowired
	OrdersDao dao;
	
	
	//������һ��dao�����Զ�ע�룬��һ����û���������,����Ӫ�������л�ȡ

	@RequestMapping("index")
	public String index(@RequestParam(defaultValue="",value="txt") String t,SearchInfo info,ModelMap m) {
		if(t.length()>0)
			info.setWhere(" where orders.goods_name like '%"+t+"%' ");
		m.put("list", dao.select(info));
		m.put("search", info);
		m.put("txt",t);
		return "Order/index";
	}
	@RequestMapping("ord")
	public String orderbytime(SearchInfo info,ModelMap m) {
		m.put("list", dao.ord(info));
		m.put("search", info);
		return "Order/index";
	}
	@RequestMapping("delete")
	public String delete(int id,ModelMap m) {
		dao.delete(id);
		return index("",new SearchInfo(),m);
	}
	@RequestMapping("insert")
	public @ResponseBody JsonInfo insert(Orders u,ModelMap m) {
		
		dao.insert(u);
		return new JsonInfo(1);
	}

	@RequestMapping("update")
	public @ResponseBody JsonInfo update(Orders u,ModelMap m,HttpServletRequest req) {//string name= User u
		dao.update(u);
		return new JsonInfo(1);
	}
	
	
	
	@RequestMapping("add")
	public String add(ModelMap m) {//string name= User u

		return "Order/edit";
	}
	
	@RequestMapping("edit")
	public String edit(int id,ModelMap m) {//string name= User u
		m.put("info", dao.getById(id));
		return add(m);
	}
	
	
	@RequestMapping("search1")
	public String search1(SearchInfo info,ModelMap m) {
		m.put("list", dao.search1(info));
		m.put("search", info);
		return "Order/index";
	}
	@RequestMapping("search2")
	public String search2(SearchInfo info,ModelMap m) {
		m.put("list", dao.search2(info));
		m.put("search", info);
		return "Order/index";
	}
	@RequestMapping("search3")
	public String search3(SearchInfo info,ModelMap m) {
		m.put("list", dao.search3(info));
		m.put("search", info);
		return "Order/index";
	}
	@RequestMapping("search4")
	public String search4(SearchInfo info,ModelMap m) {
		m.put("list", dao.search4(info));
		m.put("search", info);
		return "Order/index";
	}
	@RequestMapping("search5")
	public String search5(SearchInfo info,ModelMap m) {
		m.put("list", dao.search5(info));
		m.put("search", info);
		return "Order/index";
	}
	@RequestMapping("search6")
	public String search6(SearchInfo info,ModelMap m) {
		m.put("list", dao.search6(info));
		m.put("search", info);
		return "Order/index";
	}
	@RequestMapping("search7")
	public String search7(SearchInfo info,ModelMap m) {
		m.put("list", dao.search7(info));
		m.put("search", info);
		return "Order/index";
	}
	@RequestMapping("search8")
	public String search8(SearchInfo info,ModelMap m) {
		m.put("list", dao.search8(info));
		m.put("search", info);
		return "Order/index";
	}
}
 