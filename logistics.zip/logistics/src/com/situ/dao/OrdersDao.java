package com.situ.dao;

import java.util.List;

import org.apache.catalina.User;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import com.situ.entity.CUser;
import com.situ.entity.Orders;

import com.situ.utils.SearchInfo;

@Repository
public interface OrdersDao {


	@Select("select * from orders ${where} ${sort} ${limit}")
	public List<Orders> select(SearchInfo info);
	
	@Select("select * from orders order by time")
	public List<Orders> ord(SearchInfo info);
	
	@Select("select * from orders where id =#{id}")
	public Orders getById(int id);
	
	
	@Delete("delete from orders where id=#{id}")
	public void delete(int id);//ֻ��һ���������������ʱ��������ֻ��Ի�������
	
	@Insert("insert into orders (goods_name,order_no,"
			+ "time,poster,reciever,print_state,good_state) "
			+ "values(#{goods_name},#{order_no},#{time},#{poster},#{reciever},"
			+ "#{print_state},#{good_state})")
	public void insert(Orders u);
	
	@Insert("update orders set goods_name=#{goods_name},"
			+ "order_no=#{order_no},time=#{time},poster=#{poster},"
			+ "reciever=#{reciever},print_state=#{print_state},"
			+ "good_state=#{good_state} where id=#{id}")
	public void update(Orders u);
	
	
	@Select("select * from orders where print_state="+1)
	public List<Orders> search1(SearchInfo info);
	
	@Select("select * from orders where print_state="+0)
	public List<Orders> search2(SearchInfo info);
	
	@Select("select * from orders where good_state="+1)
	public List<Orders> search3(SearchInfo info);
	
	@Select("select * from orders where good_state="+0)
	public List<Orders> search4(SearchInfo info);
	
	@Select("select * from orders where good_state="+1+" and poster='whh'")
	public List<Orders> search5(SearchInfo info);
	
	@Select("select * from orders where good_state="+0+" and poster='whh'")
	public List<Orders> search6(SearchInfo info);
	
	@Select("select * from orders where reciever='whh'")
	public List<Orders> search7(SearchInfo info);
	
	@Select("select * from orders where poster='whh'")
	public List<Orders> search8(SearchInfo info);
}
