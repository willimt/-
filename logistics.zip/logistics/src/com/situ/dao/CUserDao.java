package com.situ.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import com.situ.entity.CUser;

import com.situ.utils.SearchInfo;

@Repository
public interface CUserDao {

	@Select("select * from common_user")
	public List<CUser> select(SearchInfo info);
	
	@Select("select * from common_user where id =#{id}")
	public CUser getById(int id);
	
	@Select("select * from common_user where username =#{username}")
	public CUser getByName(String username);
	
	@Select("select * from common_user where username =#{username} and password=#{password}")
	public CUser login(CUser u);
	
	@Delete("delete from common_user where id=#{id}")
	public void delete(int id);//ֻ��һ���������������ʱ��������ֻ��Ի�������
	
	@Insert("insert into common_user (username,password,name,address,contact) values(#{username},#{password},#{name},#{address},#{contact})")
	public void insert(CUser u);
	
	@Insert("update common_user set username=#{username},"
			+ "name=#{name},address=#{address},"
			+ " contact=#{contact}  where id=#{id}")
	public void update(CUser u);
	
	@Insert("update common_user set username=#{username},"
			+ " name=#{name},address=#{address},contact=#{contact}"
			+ ",password=#{password} where id=#{id}")
	public void updatepass(CUser u);
	
}
