package com.situ.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import com.situ.entity.LUser;

import com.situ.utils.SearchInfo;

@Repository
public interface LUserDao {

	@Select("select * from logistic_user")
	public List<LUser> select(SearchInfo info);
	
	@Select("select * from logistic_user where id =#{id}")
	public LUser getById(int id);
	
	@Select("select * from logistic_user where username =#{username}")
	public LUser getByName(String username);
	
	@Select("select * from logistic_user where username =#{username} and password=#{password}")
	public LUser login(LUser u);
	
	@Delete("delete from logistic_user where id=#{id}")
	public void delete(int id);//ֻ��һ���������������ʱ��������ֻ��Ի�������
	
	@Insert("insert into logistic_user "
			+ "(username,password,company,address,"
			+ "hotline) values(#{username},#{password},"
			+ "#{company},#{address},#{hotline})")
	public void insert(LUser u);
	
	@Insert("update logistic_user set "
			+ "username=#{username},company=#{company},"
			+ "address=#{address},hotline=#{hotline} where id=#{id}")
	public void update(LUser u);
	
	@Insert("update logistic_user set username=#{username},"
			+ " company=#{company},address=#{address},hotline=#{hotline}"
			+ ",password=#{password} where id=#{id}")
	public void updatepass(LUser u);
	
}
