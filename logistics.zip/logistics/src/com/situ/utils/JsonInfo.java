package com.situ.utils;

public class JsonInfo {
	
	public JsonInfo() {
		// TODO Auto-generated constructor stub
	}
	
	
public JsonInfo(int status) {
		super();
		this.status = status;
	}


private int status;

public int getStatus() {
	return status;
}

public void setStatus(int status) {
	this.status = status;
}

}
